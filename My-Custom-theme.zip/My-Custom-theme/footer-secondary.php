<footer>

    <div class="container">
    <?php
    wp_nav_menu(

          array(
              'theme_location' => 'footer-menu',
              //'menus' => 'Top Baar'
              'menu_class' => 'footer-bar',
          )

    );
    ?>
  </div>
</footer>

  <?php wp_footer();?>
</head>
</html>
