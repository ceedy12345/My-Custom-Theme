  <?php wp_footer();?>
</head>
</html>