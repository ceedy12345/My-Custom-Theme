<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <tittle></tittle>

    <?php wp_head();?>

</head>
<body>

<header>

    <div class="container">
    <?php
    wp_nav_menu(

          array(
              'theme_location' => 'top-menu',
              //'menus' => 'Top Baar'
              'menu_class' => 'top-bar',
          )

    );
    ?>
  </div>
</header>
